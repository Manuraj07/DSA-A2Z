### Utility Techniques and Algorithms

#### Swaping

#### Window-Sliding-Technique
