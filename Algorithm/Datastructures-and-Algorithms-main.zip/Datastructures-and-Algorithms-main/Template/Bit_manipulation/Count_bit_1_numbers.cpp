__builtin_popcount(state)
