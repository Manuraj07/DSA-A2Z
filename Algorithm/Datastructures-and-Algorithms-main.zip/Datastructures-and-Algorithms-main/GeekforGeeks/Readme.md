### GeeksforGeeks Problems

#### List of Topics

    01-Arrays-&-Strings
    02-Linked-List
    03-Stacks-&-Queues
    04-Trees
    05-Binary-Tree
    06-Binary-Search-Tree(BST)
    07-Heap
    08-Hashing
    09-Two-Pointers
    10-Searching-&-Sorting
    11-Hash-Table
    12-DFS
    13-BFS
    14-Trie
    15-Dynamic-Programming
    17-Bit-Manipulation
    18-Divide-&-Conquer
    19-Mathmatical

#### [Templates](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template)  

[Math](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/Math)  
[Binary_Index_Tree](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/Binary_Index_Tree)  
[Segment Tree](https://thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/SegmentTree)  
[Inverse_Element](https://thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/Inverse_Element)  
[Graph](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/Graph)  
[Bit_Manipulation](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/Bit_manipulation)  
[RB_Tree](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/RB_Tree)  
[2D Submatrix Summation](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/Sub_Rect_Sum_2D)
[2D difference array](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/master/Template/Diff_Array_2D)
[CPP_LANG](https://github.com/thisiskushal31/Datastructures-and-Algorithms/tree/main/Template/CPP_LANG)

> Above of the above template in C++ and java(Added soon).