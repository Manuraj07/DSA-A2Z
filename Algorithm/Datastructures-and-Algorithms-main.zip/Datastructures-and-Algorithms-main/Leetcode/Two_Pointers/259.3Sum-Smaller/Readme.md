### 259.3Sum-Smaller  

[Leetcode Link](https://leetcode.com/problems/3sum-smaller)