### 141. Linked List Cycle

#### Algorithm: fast and slow pointer     

Typical use of fast and slow pointers.The linked list of the ring will definitely make the fast pointer catch up with the slow pointer.       

> Solution 1(Accepted - C++)     
> Solution 1(Accepted - Java)     

[Leetcode Link](https://leetcode.com/problems/linked-list-cycle)        

[Leetcode Best Solution](https://leetcode.com/problems/linked-list-cycle/discuss/1829489/C%2B%2B-oror-Easy-To-Understand-oror-2-Pointer-oror-Fast-and-Slow)       
