### 86. Partition-List

[Leetcode Link](https://leetcode.com/problems/partition-list)